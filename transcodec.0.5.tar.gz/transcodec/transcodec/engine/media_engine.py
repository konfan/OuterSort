# encoding:UTF-8

import os
import subprocess
import re
import sys


def gbtoutf8(sgb):
    """
    transcode gb str to utf8
    """
    try:
        for c in ['gbk','gb2312']:
            return sgb.decode(c).encode('utf-8')
    except:
        pass
    return sgb


def _runcmd(cmdline):
    """
    Run the cmdline in shell
    return popenobj, stdout, stderr 
    """
    from subprocess import PIPE
    from subprocess import Popen
    cmd = [x for x in cmdline.split(' ') if x != '']
    p = Popen(cmd,
            #shell = True,
            bufsize = -1,
            stdin = PIPE,
            stdout = PIPE,
            stderr = PIPE,
            close_fds = True)
    return p, p.stdout, p.stderr


def _getmediainfo(stdpipe):
    """
    return the media info from input
    """
    def __infostrtodict(strlst):
        r = {}
        ptype = re.compile(r'Input #\d+, (.+), from') 
        pduration = re.compile(r'Duration:\s*(\d+[0-9]:[0-5][0-9]:[0-5][0-9])')
        pbitrate = re.compile(r'Duration:.+bitrate:\s*(\d+ kb/s)')
        presolution = re.compile(r'Video.+, (\d+x\d+), ')
        pvideo = re.compile(r'Video: (.+?), ')
        paudio = re.compile(r'Audio: (.+?), ')
        keymap = {'type':ptype,
                  'duration':pduration,
                  'bitrate':pbitrate,
                  'resolution':presolution,
                  'video':pvideo,
                  'audio':paudio,
                  }
        for k,v in keymap.items():
            for x in strlst:
                try:
                    r[k] = v.search(x).groups()[0]
                except:
                    if not r.has_key(k):
                        r[k] = 'Unknown'

        r['detail'] = strlst
        return r

    assert file == type(stdpipe)
    lines = map(gbtoutf8, stdpipe.readlines())
    lst = []
    for x in range(len(lines)):
        pos = lines[x].find("Input")
        if pos >= 0:
            lst = lines[x:]
            break
    return __infostrtodict(lst)


def getmediainfo(fname):
    """
    get media files info
    """
    fpath = os.path.abspath(fname);
    if not os.path.isfile(fpath):
        raise Exception("%s is not a valid file"%(fpath))

    fprobe = "ffprobe %s"%(fpath)
    pro, s_in, s_err = _runcmd(fprobe)
    pro.wait()
    return _getmediainfo(s_err)




def _getprogress(handle):
    """
    create a new thread, attach to handle to read the convert progress
    add getprogress method to handle
    """
    import types
    handle.curtime = 0
    handle.__running = True
    handle.getprogress = types.MethodType(lambda s:s.curtime, handle)
    stdpipe = handle.stderr
    cur_time = 0;
    pattern = re.compile(r'\d+[0-9]:[0-5][0-9]:[0-5][0-9]')
    str_cur_time = ""
    line = "no meaning"
    while line:
        line = stdpipe.readline()
        #print line
        if line.find("time=") >= 0:
            #print "src_time is %d, cur_time is %d"%(src_time, cur_time)
            m = pattern.search(line)
            if not m:
                continue
            str_cur_time = m.group()
            scale = 3600
            cur_time = 0
            for t in str_cur_time.split(":"):
                cur_time += scale * int(t)
                scale = scale / 60
            handle.curtime = cur_time
        if not handle.__running:
            break



def getprogress(handle):
    """
    query handle's convert progress
    """
    return handle.getprogress()



def _makeffmpegcmd(inputfile, outputfile, opts):
    """
    generate command line for ffmpeg, using options in opts
    return cmd string
    """
    #ffmpeg -i inputfile -opts -opts -opts outputfile
    f = lambda x: " ".join(["-%s %s"%(k,str(v)) for k,v in x.items()])
    ret = "ffmpeg -i %(input)s %(opt)s %(output)s"%{
                "input":inputfile,
                "output":outputfile,
                "opt":f(opts)
            }
    return ret


def convertmedia(src, dst, opts):
    """
    read src file, convert format to dst file
    format detail is set in opts
    """
    def isfinished(self):
        ret = self.poll()
        return ret is not None

    import threading
    import types
    cline = _makeffmpegcmd(src, dst, opts)
    handle, stdout, stderr = _runcmd(cline)
    handle.isfinished = types.MethodType(isfinished, handle)
    threading.Thread(target = _getprogress, args = (handle,)).start()
    return handle

def cancelconvert(handle):
    """
    cancel the convert process by handle
    """
    handle.kill()
    handle.__running = False
    return handle.wait()


def main():
    fname = "/mnt/hgfs/RHEL6_64/videosample/gowdv.dv"
    tmpopt = {"vcodec":"libvpx", "y":""}
    infile = "gowmcollectionv10_1080.mp4"
    outfile = "pyotest.avi"
    s = getmediainfo(fname)
    for x in s:
        print x[:-1]

testsrc = '/mnt/hgfs/RHEL6_64/videosample/PPT.mov'

if __name__ == "__main__":
    main()
