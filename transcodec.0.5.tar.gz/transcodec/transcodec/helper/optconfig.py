#-*-coding:utf-8 -*-

import sys
import os.path

class Config(dict):
    def __getattr__(self, name):
        return self[name]

config = Config({
    "convert":Config({
        })
    })

def Media(**args):
    config["convert"]["cpu-used"] = "5"
    config["convert"]["b:v"] = "500k"
    config["convert"].update(args)
    #config["convert"].get("fps",30)


env = {"convert":Media}
FULLPATH = lambda fname: os.path.join(
                    os.path.abspath('.'),
                    fname)
