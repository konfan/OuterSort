#coding=utf-8
import os
from os import path
import time
import sys
sys.path.append('..')
from engine import media_engine



def gettime(file):
    try:
        tstr = media_engine.getmediainfo(file).get('duration')
        #d = media_engine.getmediainfo(file)
        #print(d)
        return reduce(lambda x,y:60*int(x)+int(y), tstr.split(':'))
    except:
        return -1

def main():
    f = open('timecount','r')
    l = f.readlines()
    f.close()

    while l:
        lh = l[:4]
        l = l[4:]
        endtime = int(lh[2].split(' ')[-1][:-1])
        #file = lh[1].split(' ')[-1][:-1]
        file = lh[1][lh[1].find(' ')+1:][:-1]
        duration = gettime(file)
        print("%s:\tduration: %ds\tconvert time: %ds\tdiff: %ds"%
                (file, duration, endtime, endtime - duration))

if __name__ == '__main__':
	main()
