#!/bin/sh


if [ ! $UID -eq 0 ]
then
    echo "Need root permission"
    exit 1
fi

echo "uninstall convertd service"
service convertd stop 2> /dev/null
sleep 2
for pid in $(ps aux|grep -v grep|grep "convertd.py start"|awk -F ' ' '{print $2}');do
    kill -9 $pid
done
for pid in $(ps aux|grep -v grep|grep "convertd"|awk -F ' ' '{print $2}');do
    kill -9 $pid
done
chkconfig --del convertd 2> /dev/null
/bin/rm /etc/init.d/convertdaemon 2> /dev/null
/bin/rm /etc/init.d/convertd 2> /dev/null
echo "remove files"
/bin/rm -r /usr/local/transcodec 2> /dev/null
